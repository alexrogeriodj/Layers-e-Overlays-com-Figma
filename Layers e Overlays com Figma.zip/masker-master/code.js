var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
figma.showUI(__html__);
// Constants
const PHONES_SIZES = {
    IPHONE_X: {
        width: 209,
        height: 443,
    },
};
const DEFAULT_PHONE_SIZE = {
    width: 400,
    height: 400,
};
// Methods
function renderIPhoneX(withBottom, withTop) {
    const { width, height } = PHONES_SIZES.IPHONE_X;
    const bottomBar = `
        <rect x="172" y="742" width="134" height="5" rx="2.5" fill="black"/>
    `;
    const topBar = `
        <g>
            // Батарея
            <rect opacity="0.35" x="357.806" y="83.5027" width="21" height="10.3333" rx="2.16667" stroke="black"/>
            <path opacity="0.4" d="M380.306 86.6693V90.6693C381.111 90.3306 381.634 89.5425 381.634 88.6693C381.634 87.7962 381.111 87.0081 380.306 86.6693" fill="black"/>
            <rect x="359.306" y="85.0027" width="18" height="7.33334" rx="1.33333" fill="black"/>

            // Wi-fi
            <path fill-rule="evenodd" clip-rule="evenodd" d="M341.637 85.2773C343.852 85.2774 345.984 86.1289 347.59 87.6557C347.711 87.7735 347.904 87.7721 348.023 87.6523L349.179 86.4857C349.239 86.4249 349.273 86.3427 349.272 86.2571C349.272 86.1715 349.237 86.0897 349.176 86.0297C344.961 81.9901 338.311 81.9901 334.096 86.0297C334.035 86.0896 334.001 86.1715 334 86.257C333.999 86.3426 334.033 86.4249 334.093 86.4857L335.25 87.6523C335.369 87.7722 335.562 87.7737 335.683 87.6557C337.289 86.1288 339.42 85.2773 341.637 85.2773ZM341.637 89.073C342.854 89.0729 344.028 89.5255 344.931 90.3427C345.053 90.4586 345.245 90.4561 345.364 90.337L346.519 89.1703C346.579 89.1091 346.613 89.0261 346.612 88.9399C346.611 88.8536 346.576 88.7713 346.514 88.7113C343.766 86.1549 339.51 86.1549 336.762 88.7113C336.7 88.7713 336.664 88.8536 336.663 88.9399C336.662 89.0262 336.696 89.1092 336.757 89.1703L337.912 90.337C338.031 90.4561 338.223 90.4586 338.345 90.3427C339.247 89.526 340.42 89.0735 341.637 89.073ZM343.95 91.6268C343.951 91.7133 343.917 91.7967 343.856 91.8573L341.858 93.873C341.8 93.9322 341.72 93.9656 341.637 93.9656C341.553 93.9656 341.473 93.9322 341.415 93.873L339.417 91.8573C339.356 91.7967 339.322 91.7132 339.323 91.6267C339.325 91.5402 339.363 91.4583 339.427 91.4003C340.703 90.3214 342.571 90.3214 343.846 91.4003C343.91 91.4584 343.948 91.5403 343.95 91.6268Z" fill="black"/>

            // Время
            <path fill-rule="evenodd" clip-rule="evenodd" d="M112.006 96.1108C110 96.1108 108.439 94.917 108.139 93.1592H110.329C110.534 93.855 111.193 94.2944 112.021 94.2944C113.471 94.2944 114.35 92.8955 114.306 90.6982H114.174C113.691 91.6943 112.709 92.2583 111.479 92.2583C109.472 92.2583 108 90.7788 108 88.7573C108 86.5601 109.677 85 112.043 85C113.566 85 114.797 85.6665 115.529 86.9043C116.115 87.8125 116.416 89.0283 116.416 90.4712C116.416 93.9868 114.76 96.1108 112.006 96.1108ZM112.058 90.5518C113.164 90.5518 113.977 89.7681 113.977 88.7061C113.977 87.6367 113.149 86.8091 112.065 86.8091C110.981 86.8091 110.146 87.6294 110.146 88.6841C110.146 89.7681 110.952 90.5518 112.058 90.5518ZM119.529 94.7705C120.32 94.7705 120.825 94.2358 120.825 93.4961C120.825 92.7563 120.32 92.229 119.529 92.229C118.745 92.229 118.232 92.7563 118.232 93.4961C118.232 94.2358 118.745 94.7705 119.529 94.7705ZM119.529 89.3652C120.32 89.3652 120.825 88.8306 120.825 88.0908C120.825 87.3511 120.32 86.8237 119.529 86.8237C118.745 86.8237 118.232 87.3511 118.232 88.0908C118.232 88.8306 118.745 89.3652 119.529 89.3652ZM127.842 95.8398V93.9941H122.671V92.0386C123.623 90.2441 125 88.0615 126.853 85.271H129.951V92.1558H131.336V93.9941H129.951V95.8398H127.842ZM124.656 92.1045V92.2217H127.893V86.9922H127.776C126.809 88.4351 125.864 89.9146 124.656 92.1045ZM135.306 95.8398H137.517V85.271H135.313L132.581 87.1533V89.2114L135.174 87.4243H135.306V95.8398Z" fill="black"/>
        </g>
    `;
    const phone = figma.createNodeFromSvg(`
        <svg width="${width}" height="${height}" viewBox="0 0 478 828" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="${width}" height="${height}" fill="none"/>

            <g clip-path="url(#clip0)">

                // Черная рамка
                <path d="M415 219V106.6C415 77.8 392.6 56 363.8 56H115C86.2 56 62 77.9 62 106.6V150H59V177H62V202H59V253H62V268H59V319H62V720.4C62 749.2 86.3 774 115 774H363.8C392.6 774 415 749.2 415 720.4V302H419V219H415ZM281.3 78.5C281.3 80.9 279.3 82.9 276.9 82.9C274.5 82.9 272.5 80.9 272.5 78.5C272.5 76.1 274.5 74.1 276.9 74.1C279.3 74.1 281.3 76.1 281.3 78.5ZM221.8 78H260.8C262.5 78 263.8 79 263.8 80.5C263.8 82 262.5 83 260.8 83H221.8C220.1 83 218.8 82 218.8 80.5C218.8 79 220.1 78 221.8 78ZM396 718.1C396 735.6 383.1 751 365.6 751H116.6C99.1 751 84 735.6 84 718.1V104.8C84 87.4 99.2 75 116.6 75H145.4C151.5 75 153.7 74.1 154.1 81.8C154.3 85.8 155.8 88.8 158.1 91.4C160.5 93.9 163.7 96.2 167.4 97.3C169.9 98.1 172.7 99 175.4 99H180.8H301.5H306.9C309.6 99 312.4 97.9 314.9 97.1C318.6 95.9 321.9 93.9 324.2 91.4C326.6 88.9 328 86 328.2 82C328.6 74.3 330.8 74.9 336.9 74.9H365.4C382.9 74.9 395.8 87.3 395.8 104.7V718.1H396Z" fill="black"/>

                <path d="M260.8 78H221.8C220.1 78 218.8 79 218.8 80.5C218.8 82 220.1 83 221.8 83H260.8C262.5 83 263.8 82 263.8 80.5C263.8 79 262.4 78 260.8 78Z" fill="#F2F2F2"/>
                <path d="M276.9 82.9C279.33 82.9 281.3 80.9301 281.3 78.5C281.3 76.0699 279.33 74.1 276.9 74.1C274.47 74.1 272.5 76.0699 272.5 78.5C272.5 80.9301 274.47 82.9 276.9 82.9Z" fill="#F2F2F2"/>

                // Нижняя плашка
                ${withBottom == true && bottomBar}
            </g>

            ${withTop == true && topBar}
            
            <defs>
                <clipPath id="clip0">
                    <rect width="478" height="828" fill="white"/>
                </clipPath>
            </defs>
        </svg>
    `);
    phone.name = 'Iphone X';
    return phone;
}
function getPhoneSize(phone) {
    const upperPhone = phone.toUpperCase();
    const { width, height } = PHONES_SIZES[upperPhone];
    console.warn(width, height);
    console.warn(upperPhone);
    console.warn(PHONES_SIZES);
    if (width && height) {
        return {
            width,
            height,
        };
    }
    return DEFAULT_PHONE_SIZE;
}
function createInnerFrame(phone) {
    const { width, height } = getPhoneSize(phone);
    const frame = figma.createFrame();
    frame.resize(width, height);
    frame.x = 84;
    frame.y = 75;
    return frame;
}
figma.ui.onmessage = (msg) => __awaiter(this, void 0, void 0, function* () {
    const { phone, withBottom, withTop } = msg.values;
    const iphone = renderIPhoneX(withBottom, withTop);
    const innerFrame = createInnerFrame(phone);
    iphone.appendChild(innerFrame);
    // frame.resize(317, 680);
    // frame.backgrounds = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
    // frame.appendChild(iphone);
    figma.currentPage.appendChild(iphone);
    figma.closePlugin();
});
