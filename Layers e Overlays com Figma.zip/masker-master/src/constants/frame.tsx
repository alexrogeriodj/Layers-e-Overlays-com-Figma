export const FRAME = {
  OFFSET: 10,
  RIGHT_SPACE: 80,
};
