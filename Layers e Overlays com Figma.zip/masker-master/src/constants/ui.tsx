export const MAX_DEVICE_COUNT = 49;
