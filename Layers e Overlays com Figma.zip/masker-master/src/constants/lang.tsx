export const lang = {
  requiredDeviceQuantityField: 'The device quantity field is required',
  requiredDeviceQuantityFieldMoreThenZero: 'The device quantity field should be greater than 0',
  requiredDeviceField: 'The device field is required',
  hasElementsWithMask: 'The selected item already has a mask.',
};
